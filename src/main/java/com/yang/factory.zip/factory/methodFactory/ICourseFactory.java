package com.yang.factory.methodFactory;

import com.yang.factory.ICourse;

public  interface ICourseFactory {

    ICourse creat();
}
