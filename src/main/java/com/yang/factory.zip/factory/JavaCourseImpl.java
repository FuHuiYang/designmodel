package com.yang.factory;

public class JavaCourseImpl implements ICourse {

    @Override
    public void read() {
        System.out.println("读取java");
    }
}
