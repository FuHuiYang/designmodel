package com.yang.factory.abstactfactory;

public interface INote {
    void readNote();
}
