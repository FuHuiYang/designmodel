package com.yang.factory.abstactfactory;

public class JavaNote implements INote {


    @Override
    public void readNote() {
        System.out.println("读取Javanote笔记");
    }
}
