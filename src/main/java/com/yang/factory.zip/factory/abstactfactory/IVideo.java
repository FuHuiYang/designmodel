package com.yang.factory.abstactfactory;

public interface IVideo {
    void  readVideo();
}
