package com.yang.factory.abstactfactory;

public class JavaVideo implements IVideo{
    @Override
    public void readVideo() {
        System.out.println("正在读取javaVideo");
    }
}
