package com.yang.factory;

public interface ICourse {
    void read();
}
